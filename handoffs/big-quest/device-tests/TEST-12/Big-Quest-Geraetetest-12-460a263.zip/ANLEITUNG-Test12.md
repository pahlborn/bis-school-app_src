# Gerätetest12 · EV-1.1 / EV-1.2

Quellstand:460a263b394b5c9c08a7eb6cd50e1f99dae537d6
Anleitung aus docs/pruefung/2026-11-17-atlas-abgleich-evaluationen.md, Abschnitt8.3.

Zuerst dieses Gesamtpaket entpacken. Darin Paket12 und Vergleichspaket13 jeweils einzeln entpacken.

### Gerätetest12 · kurze Anleitung für Peter (EV-1.1 / EV-1.2)

Diese eine Abnahme nutzt **Test12 (N)** und **Test13 (N+1)** aus demselben Hauptstand. Beide haben dieselbe App-Kennung `de.bigquest.ipad`; nur Anzeigename und Buildnummer wechseln. Test13 ist hier das Vergleichspaket für Gerätetest12. Download, Quellcommit und SHA256 werden im Rückgabekommentar dieser PR verlinkt.

1. Auf demselben iPad Paket12 in „Dateien“ entpacken, die enthaltene `.swiftpm` in SwiftPlaygrounds öffnen und mit ▶ starten. Die Hülle öffnet die bestehende Testseite.
2. Wie beim bisherigen Test verbinden und anmelden. Die erste Umstellung von der früheren Test11-App-Kennung kann einmalige Neueingaben brauchen. Erst danach beginnt der Vergleich.
3. Oben „Claude-Schlüssel“ öffnen, den vorhandenen Schlüssel eingeben, „Im Schlüsselbund speichern“ wählen. Nur Speichern-Code, unmittelbaren Lesen-Code und AccessGroup notieren (normalerweise0/OK). Dieser Speicherschritt ruft keine KI auf; für den Test keinen Toddle-Import starten.
4. App in Playgrounds stoppen, Playgrounds im App-Umschalter vollständig schließen, Paket12 erneut starten. Lesen-Code/AccessGroup unter „Schlüsselbund beim Start“ und „Geräteverbindung gehalten:ja/nein“ notieren.
5. Ohne vorheriges Löschen der Appdaten Paket13 öffnen und starten. Vor einer erneuten Schlüssel-/Zugangscodeeingabe dieselben Angaben notieren. Das prüft den WechselN→N+1.
6. Mir nur diese Codes/AccessGroup und die Verbindungsbeobachtung schicken. Bei einem Fehler die Angaben vor erneuter Eingabe sichern. Keine Schlüssel, Passwörter oder Schuldaten senden.

**Ergebnisbogen:** Paket12 Speichern/Lesen-direkt/AccessGroup; Paket12 Neustart Lesen/AccessGroup/Verbindung; Paket13 Start Lesen/AccessGroup/Verbindung. Physischer Status bleibt NOT_TESTED bis zu Peters tatsächlicher Rückgabe. EV-1.3 und die vollständige Formular-/Übungsabnahme bleiben getrennte offene Arbeiten.


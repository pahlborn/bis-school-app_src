// swift-tools-version: 5.9
// Generated from pahlborn/bis-school-app_src. Do not hand-edit the package.
import PackageDescription
import AppleProductTypes

let package = Package(
    name: "Big Quest iPad Test 15",
    platforms: [.iOS("16.0")],
    products: [
        .iOSApplication(
            name: "Big Quest iPad Test 15",
            targets: ["AppModule"],
            bundleIdentifier: "de.bigquest.ipad",
            displayVersion: "0.152.2",
            bundleVersion: "15",
            appIcon: .placeholder(icon: .pencil),
            accentColor: .presetColor(.blue),
            supportedDeviceFamilies: [.pad],
            supportedInterfaceOrientations: [.portrait, .landscapeLeft, .landscapeRight]
        )
    ],
    targets: [.executableTarget(name: "AppModule", path: "App")]
)

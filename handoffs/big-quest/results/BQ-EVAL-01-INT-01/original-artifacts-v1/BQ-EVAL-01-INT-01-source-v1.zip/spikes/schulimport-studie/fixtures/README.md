# Synthetic import fixtures

ENTIRELY SYNTHETIC fixture generated for INT-01. No real people, dates or school records.
CSV rows are synthetic as documented here. This historical adapter test does not activate a new pilot.

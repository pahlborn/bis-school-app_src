import test from 'node:test';
import assert from 'node:assert/strict';
import {
  loadSpikeFixtures,
  mapEnvelopeToAccounts,
  normalizeFileCsv,
  normalizeSchoolsBuddyCsv,
  normalizeToddleCapture,
  runFixtureStudy,
  toCurrentImport,
  validateNeutralEnvelope,
} from '../spikes/schulimport-studie/spike.mjs';

test('Toddle-Capture: neutrales Zwischenformat ist gueltig und wird per Name+Geburtsdatum zugeordnet', async () => {
  const fixtures = await loadSpikeFixtures();
  const envelope = normalizeToddleCapture(fixtures.toddle);
  assert.deepEqual(validateNeutralEnvelope(envelope), []);
  const mapped = mapEnvelopeToAccounts(envelope, fixtures.accounts);
  assert.deepEqual(mapped.unresolved, []);
  assert.equal(mapped.students[0].account.login, 'fixture.alpha');
  assert.equal(mapped.students[0].mapping.method, 'name-birthdate');
  const converted = toCurrentImport(mapped);
  assert.deepEqual(converted.problems, []);
  assert.deepEqual(Object.keys(converted.current.kinder), ['fixture.alpha']);
  assert.equal(converted.current.kinder['fixture.alpha'].tasks.length, 2);
});

test('Dateiimport: zwei Kinder werden automatisch einem Konto zugeordnet und ins aktuelle Zielformat gewandelt', async () => {
  const fixtures = await loadSpikeFixtures();
  const envelope = normalizeFileCsv(fixtures.fileCsv);
  assert.deepEqual(validateNeutralEnvelope(envelope), []);
  const mapped = mapEnvelopeToAccounts(envelope, fixtures.accounts);
  assert.deepEqual(mapped.unresolved, []);
  assert.deepEqual(mapped.students.map((student) => student.account.login).sort(), ['fixture.alpha', 'fixture.beta']);
  const converted = toCurrentImport(mapped);
  assert.deepEqual(converted.problems, []);
  assert.deepEqual(Object.keys(converted.current.kinder).sort(), ['fixture.alpha', 'fixture.beta']);
});

test('SchoolsBuddy-Export: ohne gespeicherte Quell-ID-Zuordnung bleibt Fixture Alpha mehrdeutig, mit Zuordnung wird der Weg belastbar', async () => {
  const fixtures = await loadSpikeFixtures();
  const envelope = normalizeSchoolsBuddyCsv(fixtures.schoolsBuddyCsv);
  const auto = mapEnvelopeToAccounts(envelope, fixtures.accounts);
  assert.equal(auto.unresolved.length, 1);
  assert.equal(auto.unresolved[0].externalStudentId, 'synthetic-sb-alpha');
  assert.equal(auto.unresolved[0].reason, 'name-mehrdeutig');
  const mapped = mapEnvelopeToAccounts(envelope, fixtures.accounts, fixtures.maps['schoolsbuddy-csv']);
  assert.deepEqual(mapped.unresolved, []);
  assert.equal(mapped.students.find((student) => student.externalStudentId === 'synthetic-sb-alpha').account.login, 'fixture.alpha.two');
  const converted = toCurrentImport(mapped);
  assert.deepEqual(converted.problems, []);
  assert.deepEqual(Object.keys(converted.current.kinder).sort(), ['fixture.alpha.two', 'fixture.beta']);
});

test('Studienlauf: alle drei Wege liefern mit ihrer passenden Zuordnung ein aktuelles, validiertes Zielformat', async () => {
  const results = await runFixtureStudy();
  assert.deepEqual(results.map((row) => row.adapter), ['toddle-cdp', 'file-csv', 'schoolsbuddy-csv']);
  assert.ok(results.every((row) => row.currentTargetValid), JSON.stringify(results));
  assert.deepEqual(results.find((row) => row.adapter === 'toddle-cdp').currentTargetChildren, ['fixture.alpha']);
  assert.deepEqual(results.find((row) => row.adapter === 'file-csv').currentTargetChildren.sort(), ['fixture.alpha', 'fixture.beta']);
  assert.ok(results.find((row) => row.adapter === 'toddle-cdp').blockers.some((item) => /interaktive Anmeldung/.test(item)));
});

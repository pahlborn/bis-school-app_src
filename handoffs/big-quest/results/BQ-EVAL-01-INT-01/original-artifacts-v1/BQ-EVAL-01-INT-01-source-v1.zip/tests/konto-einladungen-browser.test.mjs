// Aufgabe "Einladungen - Oberflaeche" im Browser (Chromium): nur die Bedienwege - ⚙ oeffnen, Abschnitt "Familie"
// aufklappen, Kind anlegen, Start-QR-Code sichtbar und mit dem richtigen Startlink, das Kind wartet und geht von selbst
// weiter (echte Zeitgeber: QR-Code-Takt der Eltern, Warte-Takt des Kindes), Felder fuer den Passwortspeicher beim
// Schluessel-Erneuern, Start direkt in den Erwachsenenbereich auf dem eigenen Geraet und Abmelden. Die Logik mit
// mehreren Geraeten: tests/konto-einladungen.test.mjs.
// Speicher: der nachgebaute GitHub-Server (Weg der Testinstanz).
//   node --test tests/konto-einladungen-browser.test.mjs

import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { appServer, browserStarten } from './app-hilfen.mjs';
import { githubNachbau } from './module/github-nachbau.mjs';
import { githubSpeicher } from '../src/module/github.mjs';
import { startcodeAusstellen, ersteAnmeldung } from '../src/module/konto.mjs';
import { anmEinladungslink } from '../src/module/anmeldung.mjs';
import { qrSvg } from '../src/module/qrcode.mjs';
import { keyFingerprint } from '../src/module/krypto.mjs';

const REPO = 'pahlborn/bis-school-app-testdaten';
const TOKEN = 'github_pat_TESTTOKEN_' + 'q8Rt'.repeat(10);
let N, server, browser, startP;

before(async () => {
  N = await githubNachbau({ token: TOKEN, repos: [REPO] });
  const z = githubSpeicher({ repo: REPO, token: TOKEN, basis: N.basis }).geraet('d_Werkzeug1');
  const sc = await startcodeAusstellen({ zugang: z, aussteller: null, anmeldename: 'admin', art: 'admin', now: Date.now() });
  const admin = await ersteAnmeldung({ zugang: z, code: sc.code, passwort: 'Werkzeug-Admin-Passwort-1', now: Date.now() });
  startP = await startcodeAusstellen({ zugang: z, aussteller: admin, anmeldename: 'peter.a', art: 'parent', now: Date.now() });
  const speicher = JSON.stringify({ art: 'github', repo: REPO, wurzel: '', basis: N.basis });
  server = await appServer({ bauart: 'test', anpassen: (h) => h.replace('/*BQ_SPEICHER*/null', () => speicher) });
  browser = await browserStarten();
});
after(async () => { await browser?.close(); server?.close(); await N?.schliessen(); });

async function geraet() {
  const ctx = await browser.newContext({ acceptDownloads: true });
  await ctx.route('**/*', (r) => (r.request().url().startsWith(server.url) || r.request().url().startsWith(N.basis) ? r.continue() : r.abort()));
  await ctx.addInitScript(() => { window.AudioContext = undefined; window.webkitAudioContext = undefined; try { Object.defineProperty(navigator, 'canShare', { value: undefined }); } catch (e) { /* egal */ } });
  const page = await ctx.newPage(), fehler = [];
  page.on('pageerror', (e) => fehler.push(e.message));
  return { ctx, page, fehler };
}
/* Einladung geoeffnet (Aufgabe "Erstanmeldung per QR-Code"): Passwortformular ohne Rollenwahl, Merkpasswort, absenden */
async function registrieren(page) { await page.waitForSelector('#kontoNeuForm', { state: 'visible', timeout: 30000 }); await page.locator('#kontoNeuUse').click(); await page.locator('#kontoNeuGo').click(); }
async function verbinden(page) {
  await page.goto(server.url);
  await page.waitForSelector('#verbinden');
  await page.locator('#verbLink').fill(TOKEN);
  await page.locator('#verbGo').click();
  await page.waitForSelector('#roleAdult');
}
async function erwachsenenLogin(page, name, passwort) {
  await page.locator('#roleAdult').click();
  await page.locator('#loginUser').fill(name);
  await page.locator('#loginPw').fill(passwort);
  await page.locator('#loginGo').click();
  await page.waitForSelector('#parentClose');
}
const attr = (page, sel) => page.locator(sel).evaluate((e) => ({ autocomplete: e.getAttribute('autocomplete'), name: e.getAttribute('name'), type: e.type }));
async function togglePruefen(page, id, wert, autocomplete) {
  const feld = page.locator('#' + id), knopf = page.locator(`[data-pw-toggle="${id}"]`);
  await feld.fill(wert);
  assert.equal(await feld.getAttribute('autocomplete'), autocomplete, id + ' autocomplete');
  assert.equal(await feld.getAttribute('type'), 'password', id + ' start');
  await knopf.click();
  assert.equal(await feld.getAttribute('type'), 'text', id + ' sichtbar');
  assert.equal(await feld.inputValue(), wert, id + ' Wert sichtbar');
  await knopf.click();
  assert.equal(await feld.getAttribute('type'), 'password', id + ' wieder verdeckt');
  assert.equal(await feld.inputValue(), wert, id + ' Wert verdeckt');
}

test('Browser: Kind anlegen -> Start-QR-Code -> Kind startet sofort; Schluessel erneuern (Felder); eigenes Geraet startet direkt im Erwachsenenbereich', async () => {
  const P = await geraet();
  // die Einladung des Admins: Zugangscode und Startlink in einem Link
  const linkP = anmEinladungslink(server.url, { zugang: TOKEN, anmeldename: 'peter.a', code: startP.code, fingerabdruck: startP.fingerabdruck });
  await P.page.goto(linkP);
  await registrieren(P.page);
  await P.page.waitForSelector('#recGo', { timeout: 30000 }); await P.page.locator('#recGo').click();
  await P.page.locator('#welcomeGo').click();
  await P.page.waitForSelector('#parentClose');

  // ⚙ -> Abschnitt "Familie" aufklappen -> Kind anlegen
  await P.page.locator('#pSettings').click();
  await P.page.locator('details.psec[data-psec="family"] > summary').click();
  await P.page.locator('#kKindAnlegen').click();
  await P.page.locator('#kKindName').fill('Beispielkind');
  await P.page.locator('#kKindWeiter').click();
  await P.page.waitForSelector('#kKindLogin');
  assert.equal(await P.page.locator('#kKindLogin').inputValue(), 'beispielkind');
  await P.page.locator('#kKindGo').click();
  await P.page.waitForSelector('#kQr svg', { timeout: 30000 });
  const box = await P.page.locator('#kQr svg').boundingBox();
  assert.ok(box.width >= 200 && Math.abs(box.width - box.height) < 2, 'QR-Code gross genug und quadratisch: ' + JSON.stringify(box));
  const code = (await P.page.locator('#kCode').textContent()).trim();
  const pub = await P.page.evaluate(() => new Promise((res) => { const r = indexedDB.open('bq2_konto', 1); r.onsuccess = () => { const q = r.result.transaction('schluessel').objectStore('schluessel').getAll(); q.onsuccess = () => { res(q.result[0].pub); r.result.close(); }; }; }));
  // der QR-Code traegt auch den Zugangscode des Elterngeraets: das Kindergeraet ist damit gleich verbunden
  const linkK = anmEinladungslink(server.url, { zugang: TOKEN, anmeldename: 'beispielkind', code, fingerabdruck: await keyFingerprint(pub) });
  const d = await P.page.locator('#kQr path').getAttribute('d');
  assert.equal(d, /<path fill="#000" d="([^"]*)"/.exec(qrSvg(linkK, { ecc: 'M', rand: 4 }))[1], 'der QR-Code traegt Zugangscode und Startlink mit Peters Pruefwoertern');
  assert.match(await P.page.locator('#kQrStatus').textContent(), /Warte auf die erste Anmeldung/);

  // das Kind: QR-Link -> verbunden, ohne Rollenwahl zum Passwort -> Startseite, Aufnahme im Hintergrund
  const K = await geraet();
  await K.page.goto(linkK);
  await registrieren(K.page);
  await K.page.waitForSelector('#home:not([hidden])', { timeout: 60000 });
  await P.page.waitForFunction(() => /✓ Beispielkind ist angemeldet/.test(document.querySelector('#kQrStatus')?.textContent || ''), null, { timeout: 30000 });
  assert.equal(await P.page.locator('#kQrWeg').count(), 0);
  await P.page.locator('#kQrFertig').click();

  // ⚙ "Meine Geraete" -> Zugang neu absichern: Felder fuer den Passwortspeicher
  await P.page.locator('details.psec[data-psec="devices"] > summary').click();
  assert.match(await P.page.locator('details.psec[data-psec="devices"]').textContent(), /Meine Geräte[\s\S]*\(dieses Gerät\)[\s\S]*Zugang neu absichern[\s\S]*anderen Geräten melden Sie sich danach mit dem neuen Passwort neu an/);
  await P.page.locator('#kErneuern').click();
  await P.page.waitForSelector('#kErnForm');
  assert.match(await P.page.locator('#aboutBody').textContent(), /Zugang neu absichern[\s\S]*Wiederherstellungscode[\s\S]*anderen Geräten melden Sie sich danach mit dem neuen Passwort neu an/);
  assert.deepEqual(await attr(P.page, '#kErnForm input[autocomplete="username"]'), { autocomplete: 'username', name: 'username', type: 'text' });
  assert.deepEqual(await attr(P.page, '#kErnAlt'), { autocomplete: 'current-password', name: null, type: 'password' });
  assert.equal(await P.page.locator('#kErnForm input[autocomplete="new-password"]').count(), 2);
  await togglePruefen(P.page, 'kErnAlt', 'Werkzeug-Eltern-Passwort-1', 'current-password');
  await togglePruefen(P.page, 'kErnNeu1', 'Otter-Cake-Moss-1234', 'new-password');
  await togglePruefen(P.page, 'kErnNeu2', 'Otter-Cake-Moss-1234', 'new-password');
  await P.page.locator('#kBack').click();

  // Konto loeschen: Passwortfeld hat denselben Schalter
  await P.page.locator('#kKontoLoeschen').click();
  await P.page.waitForSelector('#kKlForm');
  await togglePruefen(P.page, 'kKlPw', 'Werkzeug-Eltern-Passwort-1', 'current-password');
  await P.page.locator('#kBack').click();

  // eigenes Geraet: nach dem Neuladen direkt wieder im Erwachsenenbereich
  await P.page.reload();
  await P.page.waitForSelector('#parentClose');
  // Abmelden: danach zur Anmeldung
  await P.page.locator('#parentClose').click();
  await P.page.waitForSelector('#login:not([hidden])');
  assert.deepEqual(P.fehler, []); assert.deepEqual(K.fehler, []);
  await P.ctx.close(); await K.ctx.close();
});

test('Browser: Admin laedt einen Elternteil ein, zeigt Link/QR, speichert die Einladung und der erste Eltern-Login klappt', async () => {
  const A = await geraet();
  await verbinden(A.page);
  await erwachsenenLogin(A.page, 'admin', 'Werkzeug-Admin-Passwort-1');
  await A.page.locator('details.psec[data-psec="administration"] > summary').click();
  const admin = A.page.locator('details.psec[data-psec="administration"]');
  await admin.locator('details[data-admin="invite-parent"] > summary').click();
  assert.deepEqual(await admin.locator('details[data-admin] > summary').allInnerTexts(), ['Elternteil einladen', 'Kontenübersicht', 'Zugangsdaten und Geräte', 'Daten exportieren und löschen', 'Versions- und Releaseinformationen']);
  await admin.locator('#kAdminElternEinladen').click();
  await A.page.waitForSelector('#kAdminForm');
  assert.match(await A.page.locator('#aboutBody').innerText(), /Rolle fest: Elternteil/);
  assert.deepEqual(await A.page.locator('#kAdminForm option').allInnerTexts(), ['Deutsch', 'English']);
  assert.equal(await A.page.locator('#kAdminForm input[type="radio"]').count(), 0, 'keine Rollenauswahl');
  await A.page.locator('#kAdminLogin').fill('mira.sonnental');
  await A.page.locator('#kAdminDisplay').fill('Mira Sonnental');
  await A.page.locator('#kAdminLang').selectOption('en');
  await A.page.locator('#kAdminGo').click();
  await A.page.waitForSelector('#kQr svg', { timeout: 30000 });
  const link = await A.page.locator('#kLink').inputValue();
  const code = (await A.page.locator('#kCode').textContent()).trim();
  const d = await A.page.locator('#kQr path').getAttribute('d');
  assert.match(link, /#zugang=.*&start=mira\.sonnental\//);
  assert.ok(link.includes('/' + code), 'Link traegt den Startcode');
  assert.equal(d, /<path fill="#000" d="([^"]*)"/.exec(qrSvg(link, { ecc: 'M', rand: 4 }))[1], 'QR-Code traegt genau den sichtbaren Link');
  const [download] = await Promise.all([A.page.waitForEvent('download'), A.page.locator('#kQrMail').click()]);
  assert.equal(download.suggestedFilename(), 'Big-Quest-invitation-mira.sonnental.html');
  await A.page.locator('#kQrFertig').click();
  if (!(await admin.evaluate((e) => e.open))) await admin.locator('summary').click();
  const inviteParent = admin.locator('details[data-admin="invite-parent"]');
  if (!(await inviteParent.evaluate((e) => e.open))) await inviteParent.locator('summary').click();
  await A.page.waitForFunction(() => /Offene Einladungen/.test(document.querySelector('#aboutBody')?.innerText || ''), null, { timeout: 30000 });
  assert.match(await admin.innerText(), /Offene Einladungen[\s\S]*Mira Sonnental/);

  const P = await geraet();
  await P.page.goto(link);
  await registrieren(P.page);
  await P.page.waitForSelector('#recGo', { timeout: 30000 });
  await P.page.locator('#recGo').click();
  await P.page.locator('#welcomeGo').click();
  await P.page.waitForSelector('#parentClose');
  assert.equal(await P.page.locator('details.psec[data-psec="administration"]').count(), 0, 'nicht als Admin angemeldet -> keine Funktion');

  if (!(await admin.evaluate((e) => e.open))) await admin.locator('summary').click();
  if (!(await inviteParent.evaluate((e) => e.open))) await inviteParent.locator('summary').click();
  await A.page.waitForSelector('details[data-admin="invite-parent"] #kAdminElternEinladen', { state: 'visible', timeout: 30000 });
  await A.page.locator('#kAdminElternEinladen').click();
  await A.page.waitForSelector('#kAdminForm');
  await A.page.locator('#kAdminLogin').fill('mira.sonnental');
  await A.page.locator('#kAdminGo').click();
  await A.page.waitForFunction(() => /Anmeldename ist schon vergeben|login name is taken/i.test(document.querySelector('#kMsg')?.textContent || ''), null, { timeout: 30000 });

  assert.deepEqual(A.fehler, []);
  assert.deepEqual(P.fehler, []);
  await A.ctx.close();
  await P.ctx.close();
});

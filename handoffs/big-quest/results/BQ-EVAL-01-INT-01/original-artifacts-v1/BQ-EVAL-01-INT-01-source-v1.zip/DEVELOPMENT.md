# INT-01 local development candidate

This source tree is a development input for BQ-EVAL-01-INT-01 v2 (EP-00/EP-09), not a release or an EP-06 acceptance. It preserves the reconstructed application source and the shared Test-11 form. No production configuration is supplied.

`werkzeug/konten.json` and `werkzeug/schuldaten.json` are optional, absent and ignored. Tests explicitly load `tests/konten-beispiel.json` and the independently invented `tests/schuldaten-beispiel.json` where needed. The import-study fixtures are independently invented synthetic records too. They do not authorize a new pilot.

`werkzeug/salz.json`, `werkzeug/testinstanz-ersatz.json` and `werkzeug/verbotene-woerter.txt` contain deliberately synthetic development configuration. The salt is public dummy data; the word list is a synthetic test sentinel, not an operator's publication approval. Never use these files as production credentials, production identity mapping or a production privacy review.

The retained `index.html` is the essential cleartext application source, with null account and school-data markers. It contains no populated original account/school payload. Generated builds, local databases, credentials and Git history are excluded from the delivery archive. Historical review records containing original-person context have been removed; they remain in the historical public repository and are not claimed erased.

## Restore and build locally

Extract the complete source archive into an empty directory. Do not overlay an old checkout containing operational data. Verify the supplied file checksums before use. With Node 24.22.1, npm and Git available:

```sh
git init
git add .
git -c user.name='Local development' -c user.email='local@example.invalid' commit -m 'Restore synthetic INT-01 source snapshot'
npm install --ignore-scripts --no-audit --no-fund --package-lock=false
node werkzeug/testinstanz.mjs --ziel ./dist-test
```

The fresh local commit differs from the original reconstruction and candidate commit metadata. The supplied Git tree reference identifies content. The build embeds the current local commit as development metadata. Creating a new local repository avoids carrying removed original records in history. Do not publish the reconstruction repository or a deletion patch/bundle from it.

For browser tests use Playwright 1.56.1 from package.json and a compatible installed Chromium (set `CHROMIUM_PATH` when necessary). The tests redirect service calls to local synthetic servers; they do not require production tokens, family data or a live Claude provider. See the separately supplied evidence for exact selected tests, commands, exit codes, candidate reference and limits.

No code push, PR, GitHub Action, merge, deployment or app publication is authorized by this document.

The legacy neutralization detector and 23 source-label mappings use explicit synthetic markers. The neutral output text and normalizer remain intact. Recognition of the removed original-person legacy labels is deliberately excluded; original operational records are not migrated by this task.

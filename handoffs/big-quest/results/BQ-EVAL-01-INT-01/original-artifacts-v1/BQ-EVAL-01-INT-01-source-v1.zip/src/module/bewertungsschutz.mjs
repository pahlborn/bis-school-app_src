import { openEntryText, sealEntry } from './krypto.mjs';
import { checkEvent, newEvent } from './ereignisse.mjs';
import { signEvent, acceptEvent } from './annahme.mjs';
import { abgleichStand, schoolEvaluationAad } from './abgleich.mjs';
import { bereichHolen } from './zulassung.mjs';
import { schuldienstEvaluation } from './schuldienst.mjs';

const BS_TEXT = new TextEncoder();
const BS_MAX_BODY = 950_000;
const bsPrefix = c => 'bq2_' + c.child + '__schoolOutbox:' + c.account.kennung + ':' + c.device + ':';
const bsSlot = (c, revision) => bsPrefix(c) + revision;
const bsArea = c => 'schule:' + c.child;
const bsSlots = scope => Array.from({ length: localStorage.length }, (_, i) => localStorage.key(i))
  .filter(slot => slot?.startsWith(scope));

async function bsDerive(secret, salt, purpose, algorithm, use) {
  const key = await crypto.subtle.importKey('raw', secret, 'HKDF', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'HKDF', hash: 'SHA-256', salt: BS_TEXT.encode(salt),
    info: BS_TEXT.encode(purpose) }, key, algorithm, false, use);
}

async function bsQueueKey(context) {
  const { privateKey, publicKey } = context.account.schluessel.ecdh;
  const secret = await crypto.subtle.deriveBits({ name: 'ECDH', public: publicKey }, privateKey, 256);
  return bsDerive(secret, bsPrefix(context), 'bq-school-evaluation-outbox-v1',
    { name: 'AES-GCM', length: 256 }, ['encrypt', 'decrypt']);
}

function bsIdentityContent(payload) {
  const normalize = value => (value ?? '').normalize('NFC').trim().replace(/\s+/g, ' ');
  const { title, day, standard, rating, focus, assessment } = payload;
  return JSON.stringify([normalize(title), day, standard, rating, focus, assessment && [
    normalize(assessment.area), normalize(assessment.goal), normalize(assessment.instructions), normalize(assessment.feedback),
    assessment.criteria.map(c => [normalize(c.criterion), c.rating, normalize(c.evidence)]),
  ]]);
}

async function bsIdentity(context, key, payload) {
  if (payload.base) return null;
  const raw = await crypto.subtle.exportKey('raw', key);
  const hmac = await bsDerive(raw, JSON.stringify([context.family, context.child]), 'bq-school-evaluation-identity-v1',
    { name: 'HMAC', hash: 'SHA-256', length: 256 }, ['sign']);
  const digest = await crypto.subtle.sign('HMAC', hmac, BS_TEXT.encode(bsIdentityContent(payload)));
  return Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, '0')).join('');
}

async function bsQueueWrite(context, key, slot, value) {
  if (!context.current()) throw new Error('ACCESS_DENIED');
  const box = await sealEntry(key, JSON.stringify(value), BS_TEXT.encode(slot));
  if (!context.current()) throw new Error('ACCESS_DENIED');
  localStorage.setItem(slot, JSON.stringify(box));
}

export async function bewertungVormerken(context, payload) {
  const event = newEvent({ type: 'school_evaluation', author: context.account.kennung, device: context.device,
    at: new Date().toISOString(), payload });
  if (checkEvent(event).length || payload.child !== context.child) throw new Error('INVALID_INPUT');
  const maximum = Math.ceil((BS_TEXT.encode(JSON.stringify({ event, sig: 'x'.repeat(88) })).length + 16) / 3) * 4 + 400;
  if (maximum > BS_MAX_BODY) throw new Error('EVALUATION_TOO_LARGE');
  const slot = bsSlot(context, payload.revision);
  const key = await bsQueueKey(context);
  if (localStorage.getItem(slot) === null) await bsQueueWrite(context, key, slot, { event, request: null });
}

const bsReads = new Map();
async function bsRead(context, state) {
  const zugang = {
    keys: () => schuldienstEvaluation(context, 'evaluation-keys', {}),
    list: (_, marker) => schuldienstEvaluation(context, 'evaluation-list',
      { cursor: marker && { bereich: marker.bereich, stand: marker.stand } }),
    get: (_, id) => schuldienstEvaluation(context, 'evaluation-bundle', { id }),
  };
  return bereichHolen(state, { zugang, ich: context.account.kennung, meineSchluessel: context.account.schluessel,
    anker: context.anchor, now: Date.now() });
}

async function bsSync(context) {
  if (!context.current()) throw new Error('ACCESS_DENIED');
  const scope = bsPrefix(context), area = bsArea(context);
  let stand = bsReads.get(scope);
  if (!stand) { stand = abgleichStand(area, context.device); bsReads.set(scope, stand); }
  const snapshot = await bsRead(context, stand);
  const slots = bsSlots(scope);
  const key = slots.length ? await bsQueueKey(context) : null;
  const outcomes = [], errors = [];
  for (const slot of slots) {
    if (!context.current()) throw new Error('ACCESS_DENIED');
    const stored = localStorage.getItem(slot);
    if (stored === null) continue;
    let pending;
    try {
      pending = JSON.parse(await openEntryText(key, JSON.parse(stored), BS_TEXT.encode(slot)));
      const { event } = pending;
      if (!pending.request) {
        const kv = snapshot.schluessel.aktuell;
        const schoolKey = snapshot.schluessel.keys.get(kv);
        if (!schoolKey) throw new Error('EVALUATION_KEY_MISSING');
        const signed = await signEvent(event, area, context.account.schluessel);
        if (!(await acceptEvent(signed, snapshot.zulassung)).ok) throw new Error('EVALUATION_RIGHTS_PENDING');
        const aad = schoolEvaluationAad(area, kv, event.id, event.author, event.device);
        const sealed = await sealEntry(schoolKey, JSON.stringify(signed), aad);
        const identityKey = snapshot.schluessel.keys.get(Math.min(...snapshot.schluessel.keys.keys()));
        pending.request = { operation: event.payload.revision, identity: await bsIdentity(context, identityKey, event.payload),
          bundle: { v: 2, kv, account: event.author, device: event.device, eintraege: [{ id: event.id, ...sealed }] } };
        await bsQueueWrite(context, key, slot, pending);
      }
      const result = await schuldienstEvaluation(context, 'evaluations', pending.request);
      if (!['saved', 'existing'].includes(result.status) || !/^e_[0-9a-f]{24}$/.test(result.event)) throw new Error('UNAVAILABLE');
      outcomes.push({ revision: event.payload.revision, ...result, slot, input: event.payload });
    } catch (error) {
      errors.push(error);
      // Only an authenticated no-receipt/stale-key response permits replacing the ciphertext.
      if (error.message === 'EVALUATION_KEY_OUTDATED' && pending?.request) {
        await bsQueueWrite(context, key, slot, { event: pending.event, request: null });
      }
      if (error.message === 'ACCESS_DENIED') break;
    }
  }
  if (outcomes.length) await bsRead(context, stand);
  if (!context.current()) throw new Error('ACCESS_DENIED');
  const accepted = new Map(stand.log.filter(entry => entry.event.type === 'school_evaluation').map(({ event }) => [event.id, event]));
  const confirmed = outcomes.filter(outcome => {
    const stored = accepted.get(outcome.event)?.payload;
    if (!stored) return false;
    if (outcome.status === 'saved') return stored.revision === outcome.input.revision;
    if (!stored.base && !outcome.input.base && bsIdentityContent(stored) === bsIdentityContent(outcome.input)) return true;
    errors.push(new Error('OPERATION_CONFLICT'));
    return false;
  });
  // A server write counts as confirmed once this device can read and verify its signed event.
  context.apply([...accepted.values()], confirmed.map(({ slot, input, ...outcome }) => ({ ...outcome,
    evaluation: accepted.get(outcome.event).payload.evaluation, confirmedRevision: accepted.get(outcome.event).payload.revision })));
  for (const outcome of confirmed) localStorage.removeItem(outcome.slot);
  if (errors.length) throw errors.find(error => error.message === 'ACCESS_DENIED' || error.message === 'OPERATION_CONFLICT') ?? errors[0];
}

const bsRunning = new Map();
export function bewertungAbgleichen(context) {
  if (!context.current()) return Promise.resolve();
  const scope = bsPrefix(context);
  if (bsRunning.has(scope)) return bsRunning.get(scope);
  const run = () => bsSync(context);
  const promise = (navigator.locks?.request('bq-school-evaluation:' + scope, run) ?? run())
    .finally(() => bsRunning.delete(scope));
  bsRunning.set(scope, promise);
  return promise;
}

export function bewertungVorgemerkt(context) {
  try { return bsSlots(bsPrefix(context)).length; }
  catch { return 0; }
}

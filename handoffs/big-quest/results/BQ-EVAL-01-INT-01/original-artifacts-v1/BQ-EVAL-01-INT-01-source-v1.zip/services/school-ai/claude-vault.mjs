import { createCipheriv, createDecipheriv, randomBytes, randomUUID } from 'node:crypto';

function seal(key, plaintext, context) {
  const nonce = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', key, nonce);
  cipher.setAAD(context);
  const encrypted = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  return { nonce: nonce.toString('base64'), tag: cipher.getAuthTag().toString('base64'), encrypted: encrypted.toString('base64') };
}

function unseal(key, sealed, context) {
  const cipher = createDecipheriv('aes-256-gcm', key, Buffer.from(sealed.nonce, 'base64'));
  cipher.setAAD(context);
  cipher.setAuthTag(Buffer.from(sealed.tag, 'base64'));
  return Buffer.concat([cipher.update(Buffer.from(sealed.encrypted, 'base64')), cipher.final()]);
}

// For loopback acceptance only. Deployment supplies a managed KMS wrapper.
export function createLocalClaudeKeyWrapper(key) {
  if (!Buffer.isBuffer(key) || key.length !== 32) throw new TypeError('A 32-byte wrapping key is required');
  return {
    localOnly: true,
    wrap: (dataKey, context) => seal(key, dataKey, context),
    unwrap: (wrapped, context) => unseal(key, wrapped, context),
  };
}

export function createClaudeVault({ scope, keyWrapper }) {
  if (typeof keyWrapper?.wrap !== 'function' || typeof keyWrapper?.unwrap !== 'function') {
    throw new TypeError('A Claude key wrapper is required');
  }
  const context = (family, version, purpose) => Buffer.from(JSON.stringify([scope, family, 'claude-api-key', version, purpose]));
  return {
    async encrypt(family, apiKey) {
      const version = randomUUID();
      const dataKey = randomBytes(32);
      try {
        const sealed = seal(dataKey, apiKey, context(family, version, 'secret'));
        const wrapped = await keyWrapper.wrap(dataKey, context(family, version, 'data-key'));
        return { version, wrapped, sealed };
      } finally {
        dataKey.fill(0);
      }
    },
    async decrypt(family, { version, sealed, wrapped }) {
      const dataKey = await keyWrapper.unwrap(wrapped, context(family, version, 'data-key'));
      if (!Buffer.isBuffer(dataKey) || dataKey.length !== 32) throw new Error('Invalid wrapped key');
      try {
        return unseal(dataKey, sealed, context(family, version, 'secret'));
      } finally {
        dataKey.fill(0);
      }
    },
  };
}

import { readFileSync } from 'node:fs';
import { openSchoolAccessStore } from './access-store.mjs';
import { githubSpeicher } from '../../src/module/github.mjs';
import { createSchoolAccountAuthority } from './account-authority.mjs';
import { githubEvaluationStore } from './evaluation-store.mjs';
import { createSchoolSessionServer } from './server.mjs';

const [command, path, first, second] = process.argv.slice(2);
if (!path || path === ':memory:' || !['import', 'code', 'serve'].includes(command) ||
  (command !== 'serve' && !first) || (command === 'code' && !second)) {
  throw new Error('Usage: run-access.mjs import|code|serve DATABASE [SNAPSHOT.json | ACCOUNT DEVICE]');
}
const access = openSchoolAccessStore(path);
if (command === 'import') {
  try { access.replaceAccount(JSON.parse(readFileSync(first, 'utf8'))); }
  finally { access.close(); }
} else if (command === 'code') {
  try { process.stdout.write(access.issueCode(first, second) + '\n'); }
  finally { access.close(); }
} else {
  const { BQ_APP_ORIGIN: origin, BQ_SERVICE_ORIGIN: audience, PORT = '8080' } = process.env;
  const port = Number(PORT);
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('Invalid port');
  const { BQ_DIRECTORY_REPO: repo, BQ_DIRECTORY_TOKEN: token, BQ_DIRECTORY_BRANCH: zweig = 'main' } = process.env;
  const request = (url, options) => fetch(url, { ...options, redirect: 'error', signal: AbortSignal.timeout(5000) });
  const storage = githubSpeicher({ repo, token, zweig, fetch: request }).geraet('d_Schuldienst');
  const directoryAuthority = createSchoolAccountAuthority({ ...access, directory: storage.directory });
  const { BQ_EVALUATIONS_REPO: evaluationRepo, BQ_EVALUATIONS_TOKEN: evaluationToken, BQ_EVALUATIONS_BRANCH: evaluationBranch = 'main' } = process.env;
  const evaluations = evaluationRepo && {
    save: githubEvaluationStore({ repo: evaluationRepo, token: evaluationToken, branch: evaluationBranch, request }),
    read: githubSpeicher({ repo: evaluationRepo, token: evaluationToken, zweig: evaluationBranch, fetch: request }).geraet('d_Schuldienst'),
  };
  createSchoolSessionServer({ origin, audience, ...access, directoryAuthority, evaluations }).listen(port, '127.0.0.1');
}

import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { test } from 'node:test';
import { abgleichStand, holen, schoolEvaluationAad } from '../../src/module/abgleich.mjs';
import { deriveSchool } from '../../src/module/ableitung.mjs';
import { signEvent } from '../../src/module/annahme.mjs';
import { newEvent } from '../../src/module/ereignisse.mjs';
import { githubSpeicher } from '../../src/module/github.mjs';
import { entryAad, newAreaKey, newPersonKeys, publicKeysOf, sealEntry, signBytes, wrapKeyFor } from '../../src/module/krypto.mjs';
import { githubNachbau } from '../../tests/module/github-nachbau.mjs';
import { openSchoolAccessStore } from './access-store.mjs';
import { githubEvaluationStore } from './evaluation-store.mjs';
import { createSchoolSessionServer } from './server.mjs';
import { schoolSessionProofText } from './session.mjs';

const repo = 'owner/evaluation-test';
const legacyToken = 'github_pat_TESTTOKEN_' + 'abcd'.repeat(10);
const serviceToken = 'github_pat_TESTTOKEN_' + 'ef12'.repeat(10);
const origin = 'http://127.0.0.1:14001';
const audience = 'http://127.0.0.1:14002';
const child = 'p_child';
const area = 'schule:' + child;
const family = 'f_test';
const title = 'Synthetischer Bewertungstext';
const criterion = 'Synthetisches Kriterium';
const day = '2026-11-15';
const now = Date.parse(day + 'T10:00:00Z');
const at = new Date(now).toISOString();
const endpoint = (action, target = child) => '/v1/children/' + target + '/' + action;

test('protected evaluations preserve scoped encrypted history, idempotency and concurrent revisions', async t => {
  const github = await githubNachbau({ token: legacyToken, gitDataToken: serviceToken, repos: [repo] });
  t.after(() => github.schliessen());
  const config = { repo, token: serviceToken, basis: github.basis };
  const legacy = githubSpeicher({ ...config, token: legacyToken }).geraet('d_legacy');
  const read = githubSpeicher(config).geraet('d_service');
  let pendingRace;
  let rejectedUpdates = 0;
  let loseResponse = false;
  const save = githubEvaluationStore({ ...config, request: async (url, options) => {
    const refUpdate = options.method === 'PATCH' && url.includes('/git/refs/');
    // Both contenders construct commits from the same parent before either ref advances.
    if (refUpdate && pendingRace) {
      const barrier = pendingRace;
      if (++barrier.arrivals === 2) {
        pendingRace = null;
        barrier.resolve();
      }
      await barrier.promise;
    }
    const response = await fetch(url, options);
    if (refUpdate && response.status === 422) rejectedUpdates++;
    if (refUpdate && response.ok && loseResponse) {
      loseResponse = false;
      throw new Error('Synthetic connection loss after commit');
    }
    return response;
  } });
  const access = openSchoolAccessStore(':memory:');
  const server = createSchoolSessionServer({ ...access, origin, audience, testLoopback: true, now: () => now, evaluations: { save, read } });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  t.after(async () => {
    await new Promise(resolve => server.close(resolve));
    access.close();
  });
  const base = 'http://127.0.0.1:' + server.address().port;
  async function web(path, input, headers = {}) {
    const response = await fetch(base + path, {
      method: 'POST', headers: { origin, 'content-type': 'application/json', ...headers },
      body: JSON.stringify(input),
    });
    assert.equal(response.headers.get('cache-control'), 'no-store');
    const data = await response.json();
    assert.ok(!JSON.stringify(data).includes(serviceToken));
    return { status: response.status, data };
  }

  async function parent(name, target = child, group = family) {
    const keys = await newPersonKeys();
    const pub = await publicKeysOf(keys);
    const account = 'p_' + name, device = 'd_' + name;
    const snapshot = { account, family: group, accountKey: pub.ecdsa, keyVersion: 1, sequence: 1,
      validUntil: now + 3_600_000, children: [target], devices: [device] };
    access.replaceAccount(snapshot);
    const deviceKeys = await newPersonKeys();
    const deviceKey = (await publicKeysOf(deviceKeys)).ecdsa;
    const pending = (await web('/v1/session/challenge', { account, device, deviceKey })).data;
    const { status, data: session } = await web('/v1/session', {
      id: pending.id, accountProof: await signBytes(keys, pending.message),
      deviceProof: await signBytes(deviceKeys, pending.message), enrollmentCode: access.issueCode(account, device, now),
    });
    assert.equal(status, 200);
    const call = async (path, input, accountProof = true) => {
      const nonce = randomUUID(), body = Buffer.from(JSON.stringify(input));
      const proof = schoolSessionProofText(session, { token: session.token, method: 'POST', path, body, at: now, nonce });
      return web(path, input, {
        authorization: 'Bearer ' + session.token, 'x-bq-at': now, 'x-bq-nonce': nonce,
        'x-bq-signature': await signBytes(deviceKeys, proof),
        ...(accountProof ? { 'x-bq-account-signature': await signBytes(keys, proof) } : {}),
      });
    };
    return { account, device, pub, keys, call, revoke: () => access.replaceAccount({ ...snapshot, sequence: 2, devices: [] }) };
  }

  const a = await parent('one');
  const b = await parent('two');
  const stranger = await parent('outsider', 'p_other', 'f_other');
  const key1 = await newAreaKey();
  const key2 = await newAreaKey();
  async function record(person, versions) {
    const versionen = {};
    for (const [version, key] of versions) {
      versionen[version] = await wrapKeyFor(key, { id: person.account, pub: person.pub }, area, version);
    }
    await legacy.putKey(area, person.account, { v: 1, von: a.account, versionen });
  }
  await record(a, [[1, key1]]);
  await record(b, [[1, key1]]);
  const admission = { area, members: {
    [a.account]: { role: 'parent', pub: a.pub, devices: [a.device, 'd_legacy'] },
    [b.account]: { role: 'parent', pub: b.pub, devices: [b.device] },
  } };
  async function evaluation(person, fields = {}, identity = null, version = 2) {
    const payload = {
      child, evaluation: randomUUID(), revision: randomUUID(), title, day, standard: 'M-N5', rating: 'C', focus: 'two-step',
      assessment: { area: 'Mathematik', goal: 'Lernziel', instructions: '', feedback: '',
        criteria: [{ criterion, rating: 'C', evidence: 'Synthetischer Beleg' }] },
      ...fields,
    };
    const event = newEvent({ type: 'school_evaluation', author: person.account, device: person.device, payload, at });
    const signed = await signEvent(event, area, person.keys);
    const aad = version === 2 ? schoolEvaluationAad(area, 1, event.id, person.account, person.device) : entryAad(area, 1, event.id);
    const sealed = await sealEntry(key1, JSON.stringify(signed), aad);
    const bundle = { v: version, kv: 1, ...(version === 2 ? { account: person.account, device: person.device } : {}),
      eintraege: [{ id: event.id, ...sealed }] };
    return { event, input: { operation: payload.revision, identity, bundle } };
  }

  const old = await evaluation({ ...a, device: 'd_legacy' }, { title: 'Synthetischer Bestand' }, null, 1);
  await legacy.put(area, 'd_legacy', { nr: 1, inhalt: old.input.bundle });
  assert.deepEqual(await b.call(endpoint('evaluation-keys'), {}), {
    status: 200, data: { [b.account]: (await read.keys(area))[b.account] },
  });
  assert.equal((await stranger.call(endpoint('evaluation-list'), { cursor: null })).status, 403);
  assert.equal((await b.call(endpoint('evaluation-list'), { cursor: { bereich: 'schule:p_other', stand: {} } })).status, 400);
  assert.equal((await b.call(endpoint('evaluation-bundle'), { id: '../other' })).status, 400);

  const identity = 'ab'.repeat(32);
  const first = await evaluation(a, {}, identity);
  const second = await evaluation(b, {}, identity);
  assert.equal((await a.call(endpoint('evaluations'), first.input, false)).status, 403);
  assert.equal((await b.call(endpoint('evaluations'), first.input)).status, 400);
  assert.equal((await a.call(endpoint('evaluations', 'p_other'), first.input)).status, 403);
  pendingRace = { ...Promise.withResolvers(), arrivals: 0 };
  const attempts = await Promise.all([a.call(endpoint('evaluations'), first.input), b.call(endpoint('evaluations'), second.input)]);
  assert.ok(attempts.every(attempt => attempt.status === 200));
  assert.deepEqual(attempts.map(attempt => attempt.data.status).sort(), ['existing', 'saved']);
  assert.equal(attempts[0].data.event, attempts[1].data.event);
  assert.equal(rejectedUpdates, 1);
  const winner = attempts[0].data.status === 'saved' ? first : second;
  assert.equal(attempts[0].data.event, winner.event.id);

  const edit = (person, text) => evaluation(person, {
    evaluation: winner.event.payload.evaluation, base: winner.event.payload.revision, title: text,
  });
  const correctionA = await edit(a, 'Korrektur A');
  const correctionB = await edit(b, 'Korrektur B');
  loseResponse = true;
  assert.equal((await a.call(endpoint('evaluations'), correctionA.input)).status, 503);
  assert.deepEqual(await a.call(endpoint('evaluations'), correctionA.input), {
    status: 200, data: { status: 'saved', event: correctionA.event.id },
  });
  assert.deepEqual(await a.call(endpoint('evaluations'), { ...correctionA.input, identity }), {
    status: 409, data: { error: 'OPERATION_CONFLICT' },
  });
  assert.equal((await b.call(endpoint('evaluations'), correctionB.input)).status, 200);

  const projection = async person => {
    const scoped = {
      async list(_area, cursor) {
        const result = await person.call(endpoint('evaluation-list'), { cursor: cursor && { bereich: cursor.bereich, stand: cursor.stand } });
        assert.equal(result.status, 200);
        return result.data;
      },
      async get(_area, id) {
        const result = await person.call(endpoint('evaluation-bundle'), { id });
        assert.equal(result.status, 200);
        return result.data;
      },
    };
    const stand = abgleichStand(area, person.device);
    await holen(stand, { zugang: scoped, schluessel: { aktuell: 1, keys: new Map([[1, key1]]) }, zulassung: admission, now });
    // A cursor with an up-to-date snapshot does not accumulate duplicates.
    await holen(stand, { zugang: scoped, schluessel: { aktuell: 1, keys: new Map([[1, key1]]) }, zulassung: admission, now });
    assert.equal(stand.log.length, 4);
    return deriveSchool(stand.log.map(item => item.event), { now });
  };
  const projected = await projection(a);
  assert.deepEqual(await projection(b), projected);
  const saved = projected.tasks.find(task => task.manual.evaluation === winner.event.payload.evaluation);
  assert.deepEqual(saved.assessment.criteria, winner.event.payload.assessment.criteria);
  assert.equal(saved.manual.revision, winner.event.payload.revision);
  assert.deepEqual(new Set(saved.manual.conflicts), new Set([correctionA.event.payload.revision, correctionB.event.payload.revision]));
  assert.equal(saved.manual.history.length, 3);
  assert.ok(projected.tasks.some(task => task.title === old.event.payload.title));

  await record(a, [[1, key1], [2, key2]]);
  const stale = await evaluation(b);
  assert.deepEqual(await b.call(endpoint('evaluations'), stale.input), {
    status: 409, data: { error: 'EVALUATION_KEY_OUTDATED' },
  });
  assert.equal((await b.call(endpoint('evaluations'), correctionB.input)).status, 200);
  b.revoke();
  assert.equal((await b.call(endpoint('evaluation-list'), { cursor: null })).status, 403);
  assert.equal((await b.call(endpoint('evaluations'), correctionB.input)).status, 403);

  const files = github.dateien();
  assert.equal([...files.keys()].filter(path => /^events\/schule:p_child\/d_/.test(path)).length, 4);
  for (const text of files.values()) {
    assert.ok(!text.includes(title) && !text.includes(criterion) && !text.includes(serviceToken));
  }
  assert.ok(github.log.filter(item => item.methode === 'PATCH').every(item => item.header.authorization === 'Bearer ' + serviceToken));
  await legacy.removeArea(area);
  assert.equal([...github.dateien().keys()].filter(path => path.includes(area)).length, 0);
});

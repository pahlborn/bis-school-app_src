// Local service foundation. A deployment needs authoritative enrollment and shared atomic storage.
import { createHash, randomBytes } from 'node:crypto';
import { verifyBytes } from '../../src/module/krypto.mjs';

const CHALLENGE_MS = 60_000;
const SESSION_MS = 15 * 60_000;
const PROOF_MS = 60_000;
const MAX_PENDING = 512;
const ID = /^[A-Za-z0-9_-]{1,128}$/;
const TOKEN = /^[A-Za-z0-9_-]{43}$/;
const publicKey = value => typeof value === 'string' && value.length <= 256 && value.length > 0 &&
  Buffer.from(value, 'base64').toString('base64') === value;
const NONCE = /^[A-Za-z0-9_-]{16,64}$/;
const familyMethods = {
  '/v1/family/claude-key/status': ['GET'],
  '/v1/family/claude-key': ['PUT', 'DELETE'],
};

const digest = value => createHash('sha256').update(value).digest('base64url');
const secret = () => randomBytes(32).toString('base64url');
const envelope = (kind, ...fields) => JSON.stringify(['bq-school-ai', 1, kind, ...fields]);
const proofText = (session, request) => envelope('request', session.origin, session.audience,
  digest(request.token), request.method, request.path, digest(request.body), request.at, request.nonce);

function localState() {
  const rows = new Map();
  return {
    get: key => rows.get(key),
    take(key) { const row = rows.get(key); rows.delete(key); return row; },
    put(key, row) { if (rows.has(key)) return false; rows.set(key, row); return true; },
    prune(at) { for (const [key, row] of rows) if (row.expires <= at) rows.delete(key); },
    size: () => rows.size,
  };
}

export function createSchoolSessions({ origin, audience, lookupDevice, bindDevice, state = localState, now = Date.now, testLoopback = false }) {
  for (const url of [origin, audience]) {
    if (new URL(url).origin !== url || (!url.startsWith('https://') && !(testLoopback && /^http:\/\/127\.0\.0\.1:\d+$/.test(url)))) throw new TypeError('HTTPS origin required');
  }
  if (typeof lookupDevice !== 'function') throw new TypeError('Authoritative device lookup required');

  const scope = digest(envelope('scope', origin, audience));
  const challenges = state(scope + ':challenge');
  const sessions = state(scope + ':session');
  const nonces = state(scope + ':nonce');

  async function authority(account, device, enrolling = false) {
    const row = await lookupDevice(account, device);
    if (!row || row.account !== account || row.device !== device || row.role !== 'parent' ||
      row.active !== true || !Number.isSafeInteger(row.validUntil) || row.validUntil <= now() ||
      !ID.test(row.family ?? '') || !Number.isSafeInteger(row.keyVersion) || row.keyVersion < 1 ||
      !Number.isSafeInteger(row.deviceVersion) || row.deviceVersion < 1 ||
      !publicKey(row.accountKey) || (!publicKey(row.deviceKey) && !(enrolling && row.deviceKey === null)) || row.accountKey === row.deviceKey ||
      !Array.isArray(row.children) || !row.children.every(child => ID.test(child))) return null;
    return { ...row, children: [...row.children] };
  }

  function matches(record, row) {
    return row && row.family === record.family && row.keyVersion === record.keyVersion &&
      row.deviceVersion === record.deviceVersion && row.accountKey === record.accountKey && row.deviceKey === record.deviceKey;
  }

  async function challenge({ origin: from, account, device, deviceKey }) {
    if (from !== origin || !ID.test(account ?? '') || !ID.test(device ?? '')) return null;
    const row = await authority(account, device, Boolean(bindDevice));
    if (!row || (row.deviceKey ? deviceKey !== undefined && row.deviceKey !== deviceKey
      : !publicKey(deviceKey) || deviceKey === row.accountKey)) return null;
    challenges.prune(now());
    if (challenges.size() >= MAX_PENDING) return null;
    const id = secret();
    const expires = now() + CHALLENGE_MS;
    const publicDeviceKey = row.deviceKey ?? deviceKey;
    const message = envelope('login', origin, audience, account, device, row.keyVersion,
      row.deviceVersion, id, expires, publicDeviceKey);
    if (!challenges.put(id, { ...row, publicDeviceKey, expires, message })) return null;
    return { id, expires, message };
  }

  async function open({ origin: from, id, accountProof, deviceProof, enrollmentCode }) {
    if (from !== origin || !TOKEN.test(id ?? '') || typeof accountProof !== 'string' ||
      typeof deviceProof !== 'string' || accountProof.length > 128 || deviceProof.length > 128) return null;
    const pending = challenges.take(id);
    if (!pending || pending.expires <= now()) return null;
    const results = await Promise.all([
      verifyBytes({ ecdsa: pending.accountKey }, pending.message, accountProof),
      verifyBytes({ ecdsa: pending.publicDeviceKey }, pending.message, deviceProof),
    ]);
    if (!results.every(Boolean)) return null;
    const row = await authority(pending.account, pending.device, Boolean(bindDevice));
    if (!matches(pending, row) || pending.sequence !== row.sequence || pending.expires <= now()) return null;
    if (!row.deviceKey && !await bindDevice(row, pending.publicDeviceKey, enrollmentCode, now())) return null;
    sessions.prune(now());
    if (sessions.size() >= MAX_PENDING) return null;
    const token = secret();
    const expires = now() + SESSION_MS;
    const { account, device, family, keyVersion, accountKey, deviceVersion } = row;
    if (!sessions.put(digest(token), { account, device, family, keyVersion, accountKey, deviceVersion, deviceKey: pending.publicDeviceKey, expires })) return null;
    return { token, expires, origin, audience };
  }

  async function authorize(request) {
    const { origin: from, token, method, path, body, at, nonce, signature, accountSignature, child } = request;
    const familyRoute = child === undefined && Object.hasOwn(familyMethods, path) && familyMethods[path].includes(method);
    const childRoute = typeof path === 'string' && typeof child === 'string' && ID.test(child) &&
      path.startsWith('/v1/children/') && path.split('/')[3] === child;
    if (from !== origin || !TOKEN.test(token ?? '') || !['GET', 'POST', 'PUT', 'DELETE'].includes(method) ||
      typeof path !== 'string' || !/^\/v1(?:\/[A-Za-z0-9_-]+)+$/.test(path) ||
      !Buffer.isBuffer(body) || body.length > (request.maxBody ?? 48_000) || !Number.isSafeInteger(at) || Math.abs(now() - at) > PROOF_MS ||
      !NONCE.test(nonce ?? '') || typeof signature !== 'string' || signature.length > 128 ||
      (!familyRoute && !childRoute)) return null;
    const tokenHash = digest(token);
    const nonceKey = tokenHash + ':' + nonce;
    const session = sessions.get(tokenHash);
    if (!session || session.expires <= now() || nonces.get(nonceKey)?.expires > now()) return null;
    const message = proofText({ origin, audience }, request);
    if (!await verifyBytes({ ecdsa: session.deviceKey }, message, signature)) return null;
    if (((familyRoute && method !== 'GET') || request.accountProofRequired === true) && (typeof accountSignature !== 'string' || accountSignature.length > 128 ||
      !await verifyBytes({ ecdsa: session.accountKey }, message, accountSignature))) return null;
    const current = async () => {
      const row = await authority(session.account, session.device);
      return matches(session, row) && (familyRoute || row.children.includes(child)) && session.expires > now();
    };
    if (!await current() || Math.abs(now() - at) > PROOF_MS) return null;
    nonces.prune(now());
    if (nonces.size() >= MAX_PENDING * 128 || !nonces.put(nonceKey, { expires: at + PROOF_MS + 1 })) return null;
    const grant = { account: session.account, device: session.device, family: session.family, child };
    return request.recheck === true ? { ...grant, current } : grant;
  }

  return { challenge, open, authorize };
}

export { proofText as schoolSessionProofText };

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { openSchoolAccessStore } from './access-store.mjs';

test('enrollment, replay state and revoked devices persist across separate connections', async t => {
  const dir = await mkdtemp(join(tmpdir(), 'bq-school-access-'));
  const path = join(dir, 'rights.sqlite');
  const first = openSchoolAccessStore(path), second = openSchoolAccessStore(path);
  t.after(async () => { first.close(); second.close(); await rm(dir, { recursive: true, force: true }); });
  const now = Date.UTC(2026, 10, 14);
  const snapshot = { account: 'p_parent', family: 'f_family', children: ['p_child'], devices: ['d_device'],
    keyVersion: 1, accountKey: 'test-account-key', sequence: 1, validUntil: now + 2_000_000 };
  first.replaceAccount(snapshot);
  const code = first.issueCode('p_parent', 'd_device', now);
  const row = second.lookupDevice('p_parent', 'd_device');
  assert.equal(JSON.stringify(row).includes(code), false);
  assert.equal(second.bindDevice(row, 'test-device-key', code, now + 600_000), false);
  assert.equal(first.bindDevice(row, 'test-device-key', code, now), true);
  assert.equal(second.bindDevice(row, 'different-device-key', code, now), false);
  assert.equal(second.lookupDevice('p_parent', 'd_device').deviceKey, 'test-device-key');

  assert.equal(first.state('nonce').put('proof', { expires: now + 1000 }), true);
  assert.equal(second.state('nonce').put('proof', { expires: now + 1000 }), false);
  assert.deepEqual(second.state('nonce').take('proof'), { expires: now + 1000 });
  assert.equal(first.state('nonce').take('proof'), null);

  first.replaceAccount({ ...snapshot, sequence: 2, devices: [] });
  assert.equal(second.lookupDevice('p_parent', 'd_device').active, false);
  assert.throws(() => second.replaceAccount(snapshot));
  assert.throws(() => second.replaceAccount({ ...snapshot, sequence: 3 }));
  assert.throws(() => second.issueCode('p_parent', 'd_device', now));
});

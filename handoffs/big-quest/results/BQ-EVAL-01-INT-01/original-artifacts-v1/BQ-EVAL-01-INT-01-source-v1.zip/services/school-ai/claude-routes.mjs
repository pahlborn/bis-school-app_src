import { ClaudeDraftError, prepareClaudeDraft } from './claude-draft.mjs';
import { createClaudeVault } from './claude-vault.mjs';

const keyPath = '/v1/family/claude-key';
const statusPath = keyPath + '/status';
const draftPath = /^\/v1\/children\/([A-Za-z0-9_-]{1,128})\/evaluation-drafts$/;
const requestId = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
const keyFormat = /^[\x21-\x7e]{1,512}$/;

const errorStatus = {
  ACCESS_DENIED: 403, INVALID_INPUT: 400, KEY_MISSING: 409, KEY_INVALID: 422,
  LIMIT: 429, REQUEST_ALREADY_USED: 409, PROVIDER_UNAVAILABLE: 502, PROVIDER_RESPONSE: 502, UNAVAILABLE: 503,
};
const fail = (send, error) => send(errorStatus[error], { error });

export function schoolClaudeRoute(path) {
  if (path === statusPath) return { methods: ['GET'] };
  if (path === keyPath) return { methods: ['PUT', 'DELETE'] };
  const child = draftPath.exec(path)?.[1];
  return child ? { child, methods: ['POST'] } : null;
}

function readInput(body, ...fields) {
  try {
    const value = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(body));
    return value && !Array.isArray(value) && typeof value === 'object' &&
      Object.keys(value).length === fields.length && fields.every(field => Object.hasOwn(value, field)) ? value : null;
  } catch {
    return null;
  }
}

export function createSchoolClaude({ scope, store, keyWrapper, model, request = fetch, now = Date.now, testLoopback }) {
  if (!store || !model || typeof request !== 'function' ||
    (!testLoopback && (keyWrapper?.localOnly || store.localOnly)) || (testLoopback && request === fetch)) {
    throw new TypeError('Claude requires a deployment store and managed key wrapper, or loopback test fixtures');
  }
  const vault = createClaudeVault({ scope, keyWrapper });

  return async function callClaude({ route, request: req, body, sessions, origin, send }) {
    const { headers, method, url: path } = req;
    const token = /^Bearer ([A-Za-z0-9_-]{43})$/.exec(headers.authorization ?? '')?.[1];
    const at = /^\d{1,15}$/.test(headers['x-bq-at'] ?? '') ? Number(headers['x-bq-at']) : NaN;
    const authorized = await sessions.authorize({
      token, origin, method, path, body, at, child: route.child, nonce: headers['x-bq-nonce'],
      signature: headers['x-bq-signature'], accountSignature: headers['x-bq-account-signature'], recheck: true,
    });
    if (!authorized) return fail(send, 'ACCESS_DENIED');
    const { family, current } = authorized;

    if (method === 'GET') {
      const configured = Boolean(await store.keyVersion(family));
      return await current() ? send(200, { configured }) : fail(send, 'ACCESS_DENIED');
    }
    if (method === 'PUT') {
      const input = readInput(body, 'apiKey');
      if (typeof input?.apiKey !== 'string' || !keyFormat.test(input.apiKey)) return fail(send, 'INVALID_INPUT');
      const record = await vault.encrypt(family, input.apiKey);
      if (!await current()) return fail(send, 'ACCESS_DENIED');
      await store.writeKey(family, record);
      return send(200, { configured: true });
    }
    if (method === 'DELETE') {
      if (!await current()) return fail(send, 'ACCESS_DENIED');
      await store.removeKey(family);
      return send(200, { configured: false });
    }

    const input = readInput(body, 'requestId', 'source');
    if (typeof input?.requestId !== 'string' || !requestId.test(input.requestId) || typeof input.source !== 'string' ||
      !input.source.trim() || input.source.length > 12_000 || /[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/.test(input.source)) {
      return fail(send, 'INVALID_INPUT');
    }
    const source = input.source.replace(/\r\n?/g, '\n').trim();
    if (!await current()) return fail(send, 'ACCESS_DENIED');
    const record = await store.readKey(family);
    if (!record) return fail(send, 'KEY_MISSING');
    const reservationError = await store.reserveAttempt(family, input.requestId, now());
    if (reservationError) return fail(send, reservationError);
    if (!await current()) return fail(send, 'ACCESS_DENIED');
    const apiKey = await vault.decrypt(family, record);
    const sameKey = async () => (await store.keyVersion(family)) === record.version;
    let outcome;
    try {
      if (!await current()) return fail(send, 'ACCESS_DENIED');
      if (!await sameKey()) return fail(send, 'KEY_MISSING');
      outcome = await prepareClaudeDraft(source, { apiKey, model, request });
    } catch (error) {
      if (!(error instanceof ClaudeDraftError)) throw error;
      outcome = error;
    } finally {
      apiKey.fill(0);
    }
    if (!await current()) return fail(send, 'ACCESS_DENIED');
    if (!await sameKey()) return fail(send, 'KEY_MISSING');
    return outcome instanceof ClaudeDraftError ? fail(send, outcome.code) : send(200, outcome);
  };
}

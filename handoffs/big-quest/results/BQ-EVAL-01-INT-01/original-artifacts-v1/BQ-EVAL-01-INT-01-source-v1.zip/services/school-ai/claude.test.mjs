import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { test } from 'node:test';
import { newPersonKeys, publicKeysOf, signBytes } from '../../src/module/krypto.mjs';
import { openSchoolAccessStore } from './access-store.mjs';
import { prepareClaudeDraft } from './claude-draft.mjs';
import { createClaudeVault, createLocalClaudeKeyWrapper } from './claude-vault.mjs';
import { createSchoolSessionServer } from './server.mjs';
import { schoolSessionProofText } from './session.mjs';

const origin = 'http://127.0.0.1:14001';
const audience = 'http://127.0.0.1:14002';
const statusPath = '/v1/family/claude-key/status';
const keyPath = '/v1/family/claude-key';
const draftPath = child => '/v1/children/' + child + '/evaluation-drafts';
const source = [
  'Learning intentions',
  'OREO teaching example: Example E',
  'Assessment Criteria',
  'Writes a case with supporting evidence',
  'C',
  'Listens to other contributions',
  'Your response',
  'Writes a case with supporting evidence',
  'Teacher rating: E',
  'Visible rubric criterion and rating in the same row:',
  'Listens to other contributions E',
].join('\n');
const providerDraft = {
  title: 'Synthetic', day: '2026-11-14', area: 'English', goal: '', instructions: '', feedback: '',
  criteria: [
    { criterion: 'OREO teaching example: Example', criterionLine: 2, teacherLine: 2 },
    { criterion: 'Writes a case with supporting evidence', criterionLine: 4, teacherLine: 5 },
    { criterion: 'Listens to other contributions', criterionLine: 6, teacherLine: 11 },
    { criterion: 'Writes a case with supporting evidence', criterionLine: 8, teacherLine: 9 },
  ],
};
const anthropicResponse = data => Response.json({
  stop_reason: 'end_turn', content: [{ type: 'text', text: JSON.stringify(data) }],
});

async function fixture(t) {
  const directory = mkdtempSync(join(tmpdir(), 'bq-claude-'));
  const path = join(directory, 'access.sqlite');
  const access = openSchoolAccessStore(path);
  const wrappingKey = createLocalClaudeKeyWrapper(Buffer.alloc(32, 240));
  const calls = [];
  let now = Date.now();
  let reply = () => anthropicResponse(providerDraft);
  const server = createSchoolSessionServer({
    ...access, origin, audience, testLoopback: true, now: () => now,
    claude: { store: access.claudeStore, keyWrapper: wrappingKey, model: 'test-model', request: (url, options) => {
      calls.push({ url, options });
      return reply();
    } },
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  t.after(async () => {
    await new Promise(resolve => server.close(resolve));
    access.close();
    rmSync(directory, { recursive: true, force: true });
  });
  const service = 'http://127.0.0.1:' + server.address().port;
  async function web(path, method, body, extra = {}) {
    const response = await fetch(service + path, {
      method, headers: { origin, ...(body ? { 'content-type': 'application/json' } : {}), ...extra },
      ...(body ? { body } : {}),
    });
    assert.equal(response.headers.get('cache-control'), 'no-store');
    return { status: response.status, data: await response.json() };
  }
  async function family(name, sharedFamily = name) {
    const accountKeys = await newPersonKeys();
    const accountKey = (await publicKeysOf(accountKeys)).ecdsa;
    const account = 'p_' + name, child = 'c_' + sharedFamily, family = 'f_' + sharedFamily;
    const first = 'd_' + name + '_first', second = 'd_' + name + '_second';
    let sequence = 0;
    const replace = (devices, children = [child]) => access.replaceAccount({
      account, family, accountKey, keyVersion: 1, validUntil: now + 3_600_000, children, devices, sequence: ++sequence,
    });
    replace([first, second]);
    async function login(device) {
      const deviceKeys = await newPersonKeys();
      const deviceKey = (await publicKeysOf(deviceKeys)).ecdsa;
      const { data: pending } = await web('/v1/session/challenge', 'POST', JSON.stringify({ account, device, deviceKey }));
      const { data: session } = await web('/v1/session', 'POST', JSON.stringify({
        id: pending.id, accountProof: await signBytes(accountKeys, pending.message),
        deviceProof: await signBytes(deviceKeys, pending.message), enrollmentCode: access.issueCode(account, device, now),
      }));
      return async (path, method, json, { dual = true, wrongBody = false } = {}) => {
        const body = json === undefined ? '' : JSON.stringify(json);
        const at = now;
        const nonce = randomUUID();
        const text = schoolSessionProofText(session, { token: session.token, method, path, at, nonce,
          body: Buffer.from(wrongBody ? '{}' : body) });
        return web(path, method, body, {
          authorization: 'Bearer ' + session.token, 'x-bq-at': at, 'x-bq-nonce': nonce,
          'x-bq-signature': await signBytes(deviceKeys, text),
          ...(dual ? { 'x-bq-account-signature': await signBytes(accountKeys, text) } : {}),
        });
      };
    }
    return { account, child, family, first, second, replace, login };
  }
  return { path, access, calls, family, advance: ms => { now += ms; }, replyWith: next => { reply = next; } };
}

test('family settings and drafts stay separated, device-bound and encrypted across database connections', async t => {
  const f = await fixture(t);
  const first = await f.family('one');
  const second = await f.family('two');
  const a = await first.login(first.first), a2 = await first.login(first.second);
  const b = await second.login(second.first);
  const keyA = 'synthetic-test-key-family-A', keyB = 'synthetic-test-key-family-B';
  assert.deepEqual(await a(statusPath, 'GET'), { status: 200, data: { configured: false } });
  assert.equal((await a(keyPath, 'PUT', { apiKey: keyA }, { dual: false })).status, 403);
  assert.equal((await a(keyPath, 'PUT', { apiKey: keyA }, { wrongBody: true })).status, 403);
  assert.equal((await a(keyPath, 'PUT', { apiKey: keyA, family: second.family })).status, 400);
  assert.deepEqual(await a(keyPath, 'PUT', { apiKey: keyA }), { status: 200, data: { configured: true } });
  assert.deepEqual(await a2(statusPath, 'GET'), { status: 200, data: { configured: true } });
  assert.deepEqual(await b(statusPath, 'GET'), { status: 200, data: { configured: false } });
  assert.equal((await b(keyPath, 'PUT', { apiKey: keyB })).status, 200);
  assert.ok(!readFileSync(f.path).includes(keyA) && !readFileSync(f.path).includes(keyB));
  const reopened = openSchoolAccessStore(f.path);
  assert.equal(reopened.claudeStore.readKey(first.family).version, f.access.claudeStore.readKey(first.family).version);
  reopened.close();

  const input = { requestId: randomUUID(), source };
  assert.equal((await a(draftPath(second.child), 'POST', input)).status, 403);
  const [firstDraft, duplicate] = (await Promise.all([
    a(draftPath(first.child), 'POST', input), a(draftPath(first.child), 'POST', input),
  ])).sort((x, y) => x.status - y.status);
  assert.equal(firstDraft.status, 200);
  assert.equal(duplicate.data.error, 'REQUEST_ALREADY_USED');
  assert.deepEqual(firstDraft.data.draft.criteria.map(row => [row.criterion, row.rating]), [
    ['Writes a case with supporting evidence', 'C'], ['Listens to other contributions', ''],
  ]);
  assert.deepEqual(firstDraft.data.warnings, ['RATING_UNVERIFIED']);
  assert.equal((await b(draftPath(second.child), 'POST', input)).status, 200);
  assert.deepEqual(f.calls.map(call => call.options.headers['x-api-key']), [keyA, keyB]);
  assert.ok(f.calls.every(call => call.url === 'https://api.anthropic.com/v1/messages' &&
    !call.options.body.includes(first.child) && !call.options.body.includes(second.child)));
  assert.ok(!readFileSync(f.path).includes('Writes a case with supporting evidence'));

  const updated = 'synthetic-replacement-for-A';
  assert.equal((await a2(keyPath, 'PUT', { apiKey: updated })).status, 200);
  assert.equal((await a(draftPath(first.child), 'POST', { ...input, requestId: randomUUID() })).status, 200);
  assert.equal(f.calls.at(-1).options.headers['x-api-key'], updated);
  first.replace([first.first]);
  assert.equal((await a2(statusPath, 'GET')).status, 403);
  assert.equal((await a2(draftPath(first.child), 'POST', { ...input, requestId: randomUUID() })).status, 403);
  assert.equal((await a(keyPath, 'DELETE', undefined, { dual: false })).status, 403);
  assert.deepEqual(await a(keyPath, 'DELETE'), { status: 200, data: { configured: false } });
  assert.equal((await a(draftPath(first.child), 'POST', { ...input, requestId: randomUUID() })).data.error, 'KEY_MISSING');
  assert.deepEqual(await b(statusPath, 'GET'), { status: 200, data: { configured: true } });
});

test('provider failures are masked, per-family limits persist, and key removal drops an in-flight draft', async t => {
  const f = await fixture(t);
  const family = await f.family('one');
  const a = await family.login(family.first);
  await a(keyPath, 'PUT', { apiKey: 'synthetic-test-key' });
  const fill = () => a(draftPath(family.child), 'POST', { requestId: randomUUID(), source });
  for (const [status, error] of [[401, 'KEY_INVALID'], [429, 'LIMIT'], [503, 'PROVIDER_UNAVAILABLE']]) {
    f.replyWith(() => new Response('must not be returned | secret provider error', { status }));
    assert.deepEqual((await fill()).data, { error });
  }
  let finish, started;
  const pending = new Promise(resolve => { finish = resolve; });
  const submitted = new Promise(resolve => { started = resolve; });
  f.replyWith(() => { started(); return pending; });
  const inflight = fill();
  await submitted;
  const reopened = openSchoolAccessStore(f.path);
  assert.equal(reopened.claudeStore.reserveAttempt(family.family, randomUUID(), Date.now()), 'LIMIT');
  reopened.close();
  assert.equal((await fill()).data.error, 'LIMIT');
  assert.equal(f.calls.length, 4);
  await a(keyPath, 'DELETE');
  finish(anthropicResponse(providerDraft));
  assert.deepEqual((await inflight).data, { error: 'KEY_MISSING' });
});

test('AEAD binds the secret version, family and environment to its wrapped data key', async () => {
  const keyWrapper = createLocalClaudeKeyWrapper(Buffer.alloc(32, 3));
  const vault = createClaudeVault({ scope: 'test', keyWrapper });
  const record = await vault.encrypt('family-a', 'test-key');
  assert.equal((await vault.decrypt('family-a', record)).toString(), 'test-key');
  await assert.rejects(vault.decrypt('family-b', record));
  await assert.rejects(vault.decrypt('family-a', { ...record, version: randomUUID() }));
  await assert.rejects(createClaudeVault({ scope: 'prod', keyWrapper }).decrypt('family-a', record));
  assert.throws(() => createSchoolSessionServer({ origin, audience, testLoopback: true,
    lookupDevice: async () => null, claude: { model: 'test', store: { localOnly: true }, keyWrapper } }),
  /loopback test fixtures/);
});

test('bounded Toddle rubric supports embedded grades and drops contradictory or unmarked scores', async () => {
  const src = [
    'Assessment Criteria',
    'Reads four-digit numbers C',
    'Rounds numbers to the nearest hundred',
    'M',
    'Solves multi-step addition problems E',
    'RS',
    'Compare the distances C',
    'Compare the distances E',
    'Your response',
    'An instructional line with OREO E',
  ].join('\n');
  const result = await prepareClaudeDraft(src, {
    apiKey: Buffer.from('test-key'), model: 'test', request: async () => anthropicResponse({
      ...providerDraft, criteria: [
        { criterion: 'Reads four-digit numbers', criterionLine: 2, teacherLine: 2 },
        { criterion: 'Rounds numbers to the nearest hundred', criterionLine: 3, teacherLine: 4 },
        { criterion: 'Solves multi-step addition problems', criterionLine: 5, teacherLine: 5 },
        { criterion: 'Compare the distances', criterionLine: 7, teacherLine: 7 },
      ],
    }),
  });
  assert.deepEqual(result.draft.criteria.map(row => row.rating), ['C', 'M', '', '']);
});

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { newPersonKeys, publicKeysOf, signBytes } from '../../src/module/krypto.mjs';
import { createSchoolSessions, schoolSessionProofText } from './session.mjs';

const origin = 'https://app.example.test';
const audience = 'https://service.example.test';

async function fixture() {
  const accountKeys = await newPersonKeys();
  const deviceKeys = await newPersonKeys();
  let time = Date.UTC(2026, 10, 14);
  const row = {
    account: 'p_parent', device: 'd_first', family: 'family_first', role: 'parent',
    active: true, validUntil: time + 2_000_000, children: ['p_child'], keyVersion: 1, deviceVersion: 1,
    accountKey: (await publicKeysOf(accountKeys)).ecdsa, deviceKey: (await publicKeysOf(deviceKeys)).ecdsa,
  };
  const service = createSchoolSessions({ origin, audience, now: () => time,
    lookupDevice: async (account, device) => account === row.account && device === row.device ? row : null });
  const challenge = () => service.challenge({ origin, account: row.account, device: row.device });
  const login = async pending => {
    const { message, id } = pending ?? await challenge();
    return {
      origin, id, accountProof: await signBytes(accountKeys, message), deviceProof: await signBytes(deviceKeys, message),
    };
  };
  const proof = async (session, fields = {}) => {
    const request = {
      origin, token: session.token, method: 'POST', path: '/v1/children/p_child/evaluation-drafts',
      child: 'p_child', at: time, nonce: 'nonce_abcdefghijklmnop', body: Buffer.from('{}'), ...fields,
    };
    request.signature = await signBytes(deviceKeys, schoolSessionProofText(session, request));
    return request;
  };
  return { service, row, challenge, login, proof, advance: ms => { time += ms; } };
}

test('both keys and the exact origin are required, and concurrent challenge reuse yields one session', async () => {
  const f = await fixture();
  assert.equal(await f.service.challenge({ account: f.row.account, device: f.row.device, origin: audience }), null);
  const invalid = await f.login();
  assert.equal(await f.service.open({ ...invalid, deviceProof: invalid.accountProof }), null);
  assert.equal(await f.service.open(invalid), null);
  const login = await f.login();
  const attempts = await Promise.all([f.service.open(login), f.service.open(login)]);
  assert.equal(attempts.filter(Boolean).length, 1);
  f.row.role = 'child';
  assert.equal(await f.challenge(), null);
});

test('each signed call binds target, body and session, consumes its nonce once and checks current authority', async () => {
  const f = await fixture();
  const session = await f.service.open(await f.login());
  const request = await f.proof(session);
  assert.equal(await f.service.authorize({ ...request, body: Buffer.from('changed') }), null);
  assert.equal(await f.service.authorize({ ...request, path: '/v1/children/p_child/another' }), null);
  assert.equal(await f.service.authorize({ ...request, token: 'a'.repeat(43) }), null);
  const foreign = await f.proof(session, { child: 'p_other', path: '/v1/children/p_other/evaluation-drafts' });
  assert.equal(await f.service.authorize(foreign), null);
  const attempts = await Promise.all([f.service.authorize(request), f.service.authorize(request)]);
  assert.equal(attempts.filter(Boolean).length, 1);
  assert.deepEqual(attempts.find(Boolean), {
    account: 'p_parent', device: 'd_first', family: 'family_first', child: 'p_child',
  });
  const second = await f.proof(session, { nonce: 'other_abcdefghijklmnop' });
  f.row.active = false;
  assert.equal(await f.service.authorize(second), null);
  f.row.active = true;
  f.row.deviceVersion++;
  assert.equal(await f.service.authorize(second), null);
});

test('expired challenges, requests, sessions and authority fail closed', async () => {
  const f = await fixture();
  const pending = await f.login();
  f.advance(60_001);
  assert.equal(await f.service.open(pending), null);
  const session = await f.service.open(await f.login());
  const proof = await f.proof(session);
  f.advance(60_001);
  assert.equal(await f.service.authorize(proof), null);
  f.advance(900_000);
  assert.equal(await f.service.authorize(await f.proof(session)), null);
  f.row.validUntil = 1;
  assert.equal(await f.challenge(), null);
});

test('HTTP login checks the browser origin and suppresses caching on session routes', async t => {
  const { createSchoolSessionServer } = await import('./server.mjs');
  const f = await fixture();
  const server = createSchoolSessionServer({ origin, audience, now: () => Date.UTC(2026, 10, 14), lookupDevice: async () => f.row });
  t.after(() => server.close());
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const url = 'http://127.0.0.1:' + server.address().port;
  const post = (path, from, data) => fetch(url + path, {
    method: 'POST', headers: { origin: from, 'content-type': 'application/json' }, body: JSON.stringify(data),
  });
  const input = { account: f.row.account, device: f.row.device, origin };
  const denied = await post('/v1/session/challenge', audience, input);
  assert.equal(denied.status, 403);
  assert.equal(denied.headers.get('access-control-allow-origin'), null);
  const pending = await post('/v1/session/challenge', origin, input);
  assert.equal(pending.status, 200);
  assert.equal(pending.headers.get('cache-control'), 'no-store');
  assert.equal(pending.headers.get('access-control-allow-origin'), origin);
  const login = await f.login(await pending.json());
  const result = await post('/v1/session', origin, login);
  assert.equal(result.status, 200);
  assert.match((await result.json()).token, /^[A-Za-z0-9_-]{43}$/);
  assert.equal((await post('/v1/session', origin, login)).status, 403);
});

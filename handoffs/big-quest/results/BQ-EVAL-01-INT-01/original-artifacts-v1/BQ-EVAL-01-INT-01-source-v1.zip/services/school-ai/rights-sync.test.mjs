import { test } from 'node:test';
import assert from 'node:assert/strict';
import { lokalerSpeicher } from '../../src/module/speicher.mjs';
import { startcodeAusstellen, ersteAnmeldung, kontoLookup, schluesselErneuern } from '../../src/module/konto.mjs';
import { newPersonKeys, publicKeysOf, signBytes } from '../../src/module/krypto.mjs';
import { openSchoolAccessStore } from './access-store.mjs';
import { createSchoolAccountAuthority } from './account-authority.mjs';
import { schoolRightsSync } from './rights-sync.mjs';

test('signed Big Quest key rotation locks the old epoch and reconciles only signed restrictions', async t => {
  const db = openSchoolAccessStore(':memory:');
  t.after(() => db.close());
  const now = Date.now(), origin = 'https://bq.example', audience = 'https://service.example';
  const directory = lokalerSpeicher({ now: () => now }).geraet('d_operator');
  const adminInvite = await startcodeAusstellen({ zugang: directory, anmeldename: 'admin', art: 'admin', now });
  const admin = await ersteAnmeldung({ zugang: directory, code: adminInvite.code, passwort: 'Tiger-Lamp-River-4271', now, runden: 1000 });
  const invite = await startcodeAusstellen({ zugang: directory, aussteller: admin, anmeldename: 'parent', art: 'parent', now });
  const parent = await ersteAnmeldung({ zugang: directory, code: invite.code, passwort: 'Otter-Cake-Moss-1234', now, runden: 1000 });
  const lookup = await kontoLookup('parent');
  const keys = await newPersonKeys(), { ecdsa: deviceKey } = await publicKeysOf(keys);
  const device = 'd_keep';
  const snapshot = { account: parent.kennung, family: parent.kennung, keyVersion: 1, accountKey: parent.pub.ecdsa,
    devices: [device, 'd_removed', 'd_unverified'], children: ['p_keep', 'p_revoked'], sequence: 1, validUntil: now + 600_000,
    directoryAnchor: { lookup, pub: parent.pub } };
  db.replaceAccount(snapshot);
  const code = db.issueCode(parent.kennung, device);
  assert.equal(db.bindDevice(db.lookupDevice(parent.kennung, device), deviceKey, code, now), true);
  const authority = createSchoolAccountAuthority({ ...db, directory: directory.directory });
  assert.ok(await authority.currentDevice(parent.kennung, device));
  const forged = createSchoolAccountAuthority({ ...db, directory: async key => {
    const entry = await directory.directory(key);
    if (key === lookup) return { ...entry, pub: { ...entry.pub, ecdsa: deviceKey } };
    return entry;
  } });
  assert.equal(await forged.currentDevice(parent.kennung, device), null);

  const rotated = await schluesselErneuern({ zugang: directory, anmeldename: 'parent', passwort: 'Otter-Cake-Moss-1234',
    neuesPasswort: 'Walrus-Taco-Pine-1357', runden: 1000 });
  assert.equal(await authority.currentDevice(parent.kennung, device), null);
  const sync = schoolRightsSync({ ...db, ...authority, origin, audience, now: () => now });
  const update = { account: parent.kennung, device, keyVersion: rotated.stand, rotation: true,
    removedDevices: ['d_removed'], removedChildren: ['p_revoked'], at: now, nonce: 'a'.repeat(32) };
  const message = JSON.stringify(['bq-school-ai', 1, 'rights-reduce', origin, audience, parent.kennung,
    update.account, device, update.keyVersion, true, update.removedDevices, update.removedChildren, now, update.nonce]);
  const deviceProof = await signBytes(keys, message);
  assert.equal(await sync({ ...update, deviceProof, accountProof: await signBytes(parent.schluessel, message) }), false);
  const signed = { ...update, deviceProof, accountProof: await signBytes(rotated.schluessel, message) };
  assert.equal(await sync({ ...signed, removedChildren: ['p_keep'] }), false);
  assert.equal(await sync(signed), true);
  assert.equal(await sync(signed), false);
  assert.deepEqual((await authority.currentDevice(parent.kennung, device)).children, ['p_keep']);
  assert.equal(await authority.currentDevice(parent.kennung, 'd_removed'), null);
  assert.equal(db.lookupDevice(parent.kennung, 'd_unverified').keyVersion, 1);
  assert.equal(await authority.currentDevice(parent.kennung, 'd_unverified'), null);
  assert.throws(() => db.replaceAccount({ ...snapshot, sequence: 2 }));
  assert.throws(() => db.replaceAccount({ ...snapshot, sequence: 2, keyVersion: rotated.stand, accountKey: rotated.pub.ecdsa, devices: [device] }));
});

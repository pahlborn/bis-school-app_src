# BQ-EVAL-01-INT-01-DEV · Rückgabe v1

Status: **BLOCKED**. Umsetzung als vollständiger lokaler Entwicklungskandidat vorhanden; erforderlicher Integrationsnachweis bleibt wegen einer fehlgeschlagenen Test-/Konfigurations-Kompatibilitätsprüfung offen. Keine weitere Korrekturschleife gestartet.

Auftrag: INT-01 v2 @ `pahlborn/agentarium` Commit `da4c7fac79c798a12e6253621f4a9b476b5879ac`. Regelpaket: Rulebook/Process 1.4 @ `9962810b895baf10f8d71dd9a1f7387cca049b77`, Rulebook §3 vollständig sowie §§4/6, Vertretungsprofil v1. Tatsächlicher Bearbeiter: separater Codex-Entwicklungsvertreter `/root/codex_bq_int01`, nicht Claude/Forge. Keine weitere Rolle durch diesen Worker delegiert. Native Host-Start-/Stopp-Exporte hier nicht verfügbar; Agent-Identität und Ergebniszustellung sind davon getrennte Laufbelege.

## Unveränderlicher Kandidat

- Originalrekonstruktion durch Atlas: `1cd11dd39f2d8caeb32f41a6f2b343d02e66b26f`, erwarteter Originalbaum `e0474ccb8681592f0ed88bcebc318ab87afd2c12` bestätigt.
- Erster lokaler Kandidat: `c5f31df69dc36bcbfab6399381a5adba9bdc3151`.
- **Eingefrorener Endstand: `d26af4a38bdc15d3cbfb5305def012f91aacbb28`. Baum: `a7bc188f4531c8d0c7bafec8900bdc98f9470974`.** Git-Arbeitsverzeichnis nach allen Endprüfungen sauber. Kein weiterer Codefix nach der Stopgrenze.
- GitHub-main und maßgebliche PR-Referenzen hat Atlas unabhängig abgeglichen; dieser Worker führte keine externen Git-Schreiboperationen aus.

## Inhalt und begründete Abweichungen

Alle zehn vorhandenen Overlay-Zieldateien waren vor Integration bytegleich zur Originalbasis `7995d696…`; Beleg `overlay-base-identity.json`. Keine neueren EP04/EP06-Dateien blind überschrieben.

Die vollständige Klartextquelle `index.html` bleibt erhalten: sie hatte bereits `/*BQ_KONTEN*/null` und `/*BQ_SCHULE*/null`, keinen befüllten ursprünglichen Betriebsdaten-Payload. Ihre drei ursprünglichen Namensreferenzen in Kommentaren wurden bereinigt. Auch Änderungen in `src/module/einladung.mjs` und `passwort.mjs` betreffen nur Kommentare. Formular, aktuelle Fragen, Lernalgorithmen und Dienstarchitektur wurden nicht umgestaltet.

Optionale ursprüngliche Konto-/Schuldateien fehlen und werden ignoriert. Frische explizit synthetische Kontenfixture aus dem Overlay, unabhängig neu gebaute synthetische Schulfixture und fünf synthetische Import-Fixtures ersetzen ursprüngliche Eingaben. Build-Salt, Ersatzliste und Sperrwortliste sind als ausschließlich synthetische Entwicklungs-Konfiguration bezeichnet. Die Sperrliste ist ein Testsentinel, keine produktive Publikationsfreigabe.

**121 tatsächlich vorhandene historische Prüfunterlagen** wurden entfernt; einzelne historische Fallpfade/Inhalte werden nicht in die Lieferfassung übernommen. Der vollständige lokale Prüfbestand bleibt für das unabhängige Review nachvollziehbar. `DELIVERY-CHANGE-SUMMARY.json` gruppiert sie und beschreibt die übrigen Änderungen. Insgesamt 186 geänderte/entfernte/neue Pfade gegenüber der Rekonstruktion, final 233 versionierte Dateien.

Nach konkreter Atlas-Entscheidung wurden außerdem 24 kodierte ursprüngliche Legacy-Literale in `PRIVATE_RE`/`LEGACY_TEXT` durch synthetische Marker ersetzt: eine Detektionsregex und 23 Alttext-Schlüssel. **Die 23 neutralen Ergebnis-Texte und der Neutralisierungsmechanismus sind unverändert.** Bewusste Grenze: genau diese entfernten Original-Altdatenbezeichner werden nicht mehr erkannt. Original-Betriebsdaten sind ausdrücklich nicht zu migrieren. Die Entscheidung und ihr Umfang müssen unabhängig durch Argus beurteilt werden.

## Tatsächliche Prüfungen und rote Vorgeschichte

Umgebung: Node v24.22.1, Playwright 1.56.1, Chromium 156.0.8078.79 (Debian GNU/Linux 13), `CHROMIUM_PATH=/usr/bin/chromium`.

- Erster breiter Integrationslauf: **545 Tests, 509 PASS / 36 FAIL**, 0 cancelled/skipped. Auswahl: voller Modulsatz, alle damals geänderten Testgruppen, School-AI/EP04/EP06. Danach konkret diagnostizierte synthetische Input-/Erwartungsfehler korrigiert. Historischer Upgradefall hatte zuerst eine fehlende Git-Referenz im shallow Checkout.
- Erster Korrekturlauf: **92 Tests, 79 PASS / 13 FAIL**. Zweiter begrenzter Korrekturlauf: **48 Tests, 47 PASS / 1 FAIL**. Keine fehlgeschlagene Geschichte gelöscht.
- Diese Entwicklungsnachläufe fanden bei Git-HEAD `c5f31df…` mit uncommitteten Fixture-/Konfigurationskorrekturen statt; ein vollständiger unveränderlicher Ausführungsbaum wurde dabei nicht gesichert. Sie sind ausdrücklich **keine Endstandsabnahme**. `test-result-summary.json` nennt diese Grenze.
- **Finaler vollständiger lokaler Testbuild an `d26af4a…`: PASS, Exit 0**, alle vorhandenen Build-Suchprüfungen grün. Kommando: `node werkzeug/testinstanz.mjs --ziel /workspace/work/evidence/final-testbuild`. Version zeigt den finalen sauberen Commit, keine Releasefreigabe.
- **Finale Neutral-/Altlasten-Suiten an `d26af4a…`: 11/11 PASS, Exit 0.** Enthalten 23 synthetische Legacy-Schlüssel, `sheetPrompt`/`neutralQ`, unsicheren unmapped-Fallback sowie vorhandene gespeicherte Altlastenfälle. Isolierte In-memory-Gegenprobe mit deaktivierter Detektionsregex: 23/23 erwartete Fehl-Erkennungen gegenüber 0 am Kandidaten. Quelle unverändert, Beleg `LEGACY-COUNTERCHECK.json`.
- **Finaler ausdrücklich auf EINEN Versuch begrenzter Testinstanz-Nachlauf an `d26af4a…`: 11 Tests, 10 PASS / 1 FAIL, Exit 1.** Danach definitiv gestoppt.

Der letzte Fail liegt in `tests/testinstanz.test.mjs:111`: nach Präfixnormalisierung unterscheiden sich fünf Zeilen; die historische Strukturprobe erwartet mindestens zehn und höchstens vierzig. Die ursprünglichen Identitätsersetzungen, auf denen die Mindestzahl beruhte, entfallen nun. Der zuvor bemängelte Adressassert ist korrekt auf den normalisierten Origin rebasiert; Altpfad-Abwesenheit und exakte Schulfreigabe-Konfiguration bleiben geprüft. Kein beobachteter Routing-/Formularfehler wird daraus behauptet. **Keine weitere Assertkorrektur ohne nächsten konkreten Steuerungsentscheid vorgenommen.**

Ein zweiter offener historischer Fall: `evaluation-upgrade-browser.test.mjs:151` erwartet nach Kindregistrierung einen `#welcomeGo`-Klick und läuft nach 60 Sekunden aus. Die Datei ist gegenüber dem Originalbaum unverändert. Der jüngere, ebenfalls unveränderte `evaluation-eltern-browser.test.mjs:186` erwartet an derselben Stelle direkt `#home` und bestand im Erstlauf. Das stützt eine veraltete Testsetup-Annahme, beweist keinen US202-Produktfehler. Kein weiterer 60-Sekunden-Lauf, keine Gerätebeitritts- oder Produktkorrektur ausgeführt.

## Privacy, Lieferung und Grenzen

`FINAL-PRIVACY-SCAN.json`: vollständiger versionierter Endbestand geprüft, keine Treffer ursprünglicher Konto-IDs/-Hashes/-Salts, keine originalen 24 kodierten Legacy-Literale, keine Datenbankdateien; optionale Betriebsdateien fehlen. Muster-/Needle-Scans ergänzen die semantische Sichtung und ersetzen Argus nicht. Verbliebene tokenähnliche Testliterale sind deterministische Dummy-/Nachbauwerte in ausdrücklichen synthetischen Tests, keine produktiven Schlüssel.

Rawlogs und frühere unbereinigte Git-Historie bleiben lokal. **Nur `redacted-logs/` zur Lieferung verwenden**; Redaktionshinweise enthalten keine Originalwerte oder Zuordnung. Fehlerzahlen und Befunde bleiben sichtbar. Keine Löschdiffs, Git-Bundles, ursprünglichen Daten oder Git-Metadaten in ein Lieferarchiv aufnehmen. Atlas erstellt das vollständige Quellpaket aus den finalen HEAD-Blobs und prüft dessen Baum/Prüfsummen; ein bereinigtes Snapshot-Archiv mit `DEVELOPMENT.md` ist der Wiederherstellungsweg, nicht die lokale Rekonstruktionshistorie.

Keine Code-Pushes, PRs, externen Actions, Merges, Deployments oder App-Veröffentlichungen durch diesen Worker. Git-Push-Simulationen in den Tests gingen ausschließlich an temporäre lokale Bare-Repositories. Keine Claude-API-Aufrufe; tatsächliche Codex-Kosten sind hier nicht verfügbar, nicht als null behauptet. Historische öffentliche Kopien wurden nicht entfernt.

## Prozessbefund und nächster Owner

**Second-rework-Trigger vorhanden:** nach wiederholter Fehlkorrektur derselben Testinstanz-Struktur-/Konfigurationsprobe wurde die automatische Schleife gestoppt. Atlas gestattete danach genau einen diagnostisch begründeten, begrenzten Nachlauf; dessen neuer Restbefund bleibt FAIL/BLOCKED. Ursachen: zu breites Namensersetzungsschema ohne vorherige Längen-/Referenz-/Negativkontextprüfung; Verlust unveränderlicher Inputbindung während früher Entwicklungsläufe. Keine neue Prozessregel eigenmächtig eingeführt. Atlas routet den Prozessbefund separat nach geltenden Möglichkeiten.

Nächster Owner: **Atlas**, unabhängiges Argus-Review des unveränderten `d26af4a…`, Konsolidierung/Artefakte und BLOCKED-Rückgabe an zentrale Steuerung. Danach entscheidet ausschließlich zentrale Steuerung über eine konkrete nächste Korrektur oder begrenzte Wiederaufnahme. Dieser Worker beginnt keinen Folgeauftrag und nimmt keine Kundenabnahme vor.

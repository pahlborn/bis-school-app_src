# Gesicherten BLOCKED-Kandidaten wiederherstellen

Das Quellarchiv enthält den vollständigen bereinigten Snapshot, keine Git-Historie und keinen Löschpatch. Es ist kein abgenommener Release. Zum Stand gehören der rote Testinstanzbefund A1 und die übrigen ausdrücklich offenen Nachweise.

1. SHA256 des ZIP gegen SHA256SUMS.txt prüfen, anschließend den Inhalt in ein leeres Verzeichnis entpacken. Keinen alten Checkout mit Betriebsdaten überlagern.
2. Jedes Mitglied und dessen SHA256/Modus mit source-manifest.json vergleichen. Der geprüfte Git-Inhaltsbaum ist `a7bc188f4531c8d0c7bafec8900bdc98f9470974`; die ursprüngliche lokale Commitmetadaten-Historie wird absichtlich nicht mitgeliefert.
3. DEVELOPMENT.md im Snapshot befolgen: neues lokales Git-Repository initialisieren und Snapshot committen; mit Node24.22.1/npm die unveränderten Paketabhängigkeiten installieren, lokalen Testbuild erzeugen. Dafür sind keine echten Konten, Schul-/Familiendaten oder produktiven API-Schlüssel nötig. Browserprüfungen brauchen kompatibles Chromium/Playwright.
4. Der neue lokale Commit und damit die eingebettete Entwicklungs-Buildkennung unterscheiden sich. Die Source-Byte-/Modusidentität ist durch den Inhaltsbaum belegt. Aktueller Buildbeleg, rote Geschichte und Grenzen befinden sich im Evidence-Paket.

Die Wiederherstellungsprüfung erfolgte aus den tatsächlichen ZIP-Bytes: Baum identisch; Argus prüfte unabhängig sämtliche233Blobinhalte/Modi, Manifestprüfsummen, ZIP-CRC und Pfadmenge gegen den eingefrorenen Kandidaten. Kein zusätzlicher Installationslauf aus dem entpackten Archiv wurde behauptet. Keine Veröffentlichung oder weitere Arbeit ist durch diese Anleitung freigegeben.
